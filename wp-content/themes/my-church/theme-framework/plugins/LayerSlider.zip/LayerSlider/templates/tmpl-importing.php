<?php if(!defined('LS_ROOT_FILE')) { header('HTTP/1.0 403 Forbidden'); exit; } ?>
<script type="text/html" id="tmpl-importing">
	<div id="ls-importing-modal-window">
		<div class="layerslider-logo"></div>
	</div>
</script>